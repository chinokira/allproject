window._env = {
  BACKEND_URL: "${BACKEND_URL}"
};