import { InsertError2Directive } from './insert-error2.directive';

describe('InsertError2Directive', () => {
  it('should create an instance', () => {
    // const directive = new InsertError2Directive();
    // expect(directive).toBeTruthy();
  });
});
