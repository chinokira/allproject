package fr.formation.poll_backend_webservice_springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PollBackendWebserviceSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
