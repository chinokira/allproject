import { InsertErrorsDirective } from './insert-errors.directive';

describe('InsertErrorsDirective', () => {
  it('should create an instance', () => {
    // const directive = new InsertErrorsDirective();
    // expect(directive).toBeTruthy();
  });
});
