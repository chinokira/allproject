
export interface Option {
  id: number;
  name: string;
  votes: number;
}
