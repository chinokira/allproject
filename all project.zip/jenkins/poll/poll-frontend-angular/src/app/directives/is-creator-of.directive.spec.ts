import { IsCreatorOfDirective } from './is-creator-of.directive';

describe('IsCreatorOfDirective', () => {
  it('should create an instance', () => {
    // const directive = new IsCreatorOfDirective();
    // expect(directive).toBeTruthy();
  });
});
