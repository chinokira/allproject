export const environment = {
  backendUrl: 'http://localhost:8080/'
}; 