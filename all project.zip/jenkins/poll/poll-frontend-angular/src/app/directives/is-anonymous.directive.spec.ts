import { IsAnonymousDirective } from './is-anonymous.directive';

describe('IsAnonymousDirective', () => {
  it('should create an instance', () => {
    // const directive = new IsAnonymousDirective();
    // expect(directive).toBeTruthy();
  });
});
