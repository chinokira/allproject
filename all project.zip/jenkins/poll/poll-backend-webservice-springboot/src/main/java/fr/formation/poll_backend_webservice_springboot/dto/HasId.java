package fr.formation.poll_backend_webservice_springboot.dto;

public interface HasId {
    long getId();
    void setId(long id);
}
