import { RunAwayDirective } from './run-away.directive';

describe('RunAwayDirective', () => {
  it('should create an instance', () => {
    // const directive = new RunAwayDirective();
    // expect(directive).toBeTruthy();
  });
});
