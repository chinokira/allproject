export const environment = {
  backendUrl: 'http://vps-3f8dfeab.vps.ovh.net:8080/'

};
